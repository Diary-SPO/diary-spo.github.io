(() => {
  // ../shared/src/api/original/index.ts
  var Grade = {
    Five: 5,
    Four: 4,
    Three: 3,
    Two: 2,
    Success: "Зч",
    "": "Д"
  };
  // ../diary-client/src/grade-notifications.ts
  var entryKey = (subjectName, day) => JSON.stringify([subjectName, day]);
  var normalizeDay = (day) => (day instanceof Date ? day.toISOString() : String(day)).slice(0, 10);
  var sortedMarks = (marks) => [...marks].sort();
  var createGradeSnapshot = (performance) => {
    const entries = {};
    for (const subject of performance.daysWithMarksForSubject) {
      for (const dayWithMarks of subject.daysWithMarks ?? []) {
        const day = normalizeDay(dayWithMarks.day);
        entries[entryKey(subject.subjectName, day)] = {
          day,
          marks: sortedMarks(dayWithMarks.markValues),
          subjectName: subject.subjectName
        };
      }
    }
    return { entries, version: 1 };
  };
  var subtractMarks = (source, valuesToRemove) => {
    const result = [...source];
    for (const value of valuesToRemove) {
      const index = result.indexOf(value);
      if (index !== -1)
        result.splice(index, 1);
    }
    return result;
  };
  var commonMarks = (first, second) => {
    const available = [...second];
    const common = [];
    for (const mark of first) {
      const index = available.indexOf(mark);
      if (index === -1)
        continue;
      common.push(mark);
      available.splice(index, 1);
    }
    return common;
  };
  var diffGradeSnapshots = (previous, current) => {
    const changes = [];
    const keys2 = new Set([
      ...Object.keys(previous.entries),
      ...Object.keys(current.entries)
    ]);
    for (const key of keys2) {
      const previousEntry = previous.entries[key];
      const currentEntry = current.entries[key];
      const entry = currentEntry ?? previousEntry;
      if (!entry)
        continue;
      const unchanged = commonMarks(previousEntry?.marks ?? [], currentEntry?.marks ?? []);
      const removed = subtractMarks(previousEntry?.marks ?? [], unchanged);
      const added = subtractMarks(currentEntry?.marks ?? [], unchanged);
      const updatedCount = Math.min(removed.length, added.length);
      for (let index = 0;index < updatedCount; index++) {
        changes.push({
          ...entry,
          mark: added[index],
          previousMark: removed[index],
          type: "UPDATE"
        });
      }
      for (const mark of added.slice(updatedCount)) {
        changes.push({ ...entry, mark, type: "ADD" });
      }
      for (const mark of removed.slice(updatedCount)) {
        changes.push({ ...entry, mark, type: "DELETE" });
      }
    }
    return changes;
  };
  var displayMark = (mark) => String(Grade[mark] ?? mark);
  var markIcon = (mark) => ({
    "": "\uD83D\uDCD8",
    Five: "5️⃣",
    Four: "4️⃣",
    Success: "✅",
    Three: "3️⃣",
    Two: "2️⃣"
  })[mark];
  var displayDay = (day) => {
    const [year, month, date] = day.split("-");
    return date && month && year ? `${date}.${month}.${year}` : day;
  };
  var formatGradeNotification = (change) => {
    const place = `${change.subjectName}, ${displayDay(change.day)}`;
    if (change.type === "UPDATE") {
      return {
        body: `${displayMark(change.previousMark)} → ${displayMark(change.mark)} · ${place}`,
        title: `${markIcon(change.mark)} Оценка изменена`
      };
    }
    return {
      body: `${displayMark(change.mark)} · ${place}`,
      title: change.type === "ADD" ? `${markIcon(change.mark)} Новая оценка` : `❌ Оценка ${displayMark(change.mark)} удалена`
    };
  };
  // src/background/grade-check-schedule.ts
  var NIGHT_INTERVAL_MINUTES = 120;
  var isGradeCheckNight = (date) => {
    const hour = date.getHours();
    return hour >= 20 || hour < 6;
  };
  var getGradeCheckInterval = (date, configuredIntervalMinutes) => isGradeCheckNight(date) ? Math.max(configuredIntervalMinutes, NIGHT_INTERVAL_MINUTES) : configuredIntervalMinutes;
  var shouldRunGradeCheck = (now, lastCheck, configuredIntervalMinutes) => !lastCheck || now.getTime() - lastCheck >= getGradeCheckInterval(now, configuredIntervalMinutes) * 60 * 1000;

  // src/background/runner-storage.ts
  var getRunnerStoredValue = (storage, key) => storage.get(key)?.value ?? null;

  // src/background/grade-runner.ts
  var runner = globalThis;
  var STORAGE = {
    baseUrl: "gradeBaseUrl",
    cookie: "gradeCookie",
    lastCheck: "gradeLastCheck",
    notificationId: "gradeNotificationId",
    settings: "gradeSettings",
    snapshot: "gradeSnapshot",
    studentId: "gradeStudentId"
  };
  var DEFAULT_SETTINGS = {
    enabled: false,
    intervalMinutes: 30
  };
  var stored = (key) => getRunnerStoredValue(CapacitorKV, key);
  var parseSettings = () => {
    const value = stored(STORAGE.settings);
    if (!value)
      return DEFAULT_SETTINGS;
    try {
      const parsed = JSON.parse(value);
      return {
        enabled: parsed.enabled === true,
        intervalMinutes: [15, 30, 60, 120].includes(Number(parsed.intervalMinutes)) ? Number(parsed.intervalMinutes) : DEFAULT_SETTINGS.intervalMinutes
      };
    } catch {
      return DEFAULT_SETTINGS;
    }
  };
  var shouldCheck = (now, settings) => {
    const lastCheck = Number(stored(STORAGE.lastCheck) ?? 0);
    return shouldRunGradeCheck(now, lastCheck, settings.intervalMinutes);
  };
  var nextNotificationId = () => {
    const previous = Number(stored(STORAGE.notificationId) ?? 0);
    const next = previous >= 2147483000 ? 1 : previous + 1;
    CapacitorKV.set(STORAGE.notificationId, String(next));
    return next;
  };
  var runGradeCheck = async () => {
    const settings = parseSettings();
    const now = new Date;
    if (!settings.enabled || !shouldCheck(now, settings))
      return;
    const baseUrl = stored(STORAGE.baseUrl);
    const cookie = stored(STORAGE.cookie);
    const studentId = Number(stored(STORAGE.studentId));
    if (!baseUrl || !cookie || !Number.isInteger(studentId) || studentId <= 0) {
      return;
    }
    const response = await fetch(`${baseUrl.replace(/\/$/, "")}/services/reports/current/performance/${studentId}`, {
      headers: {
        "Content-Type": "application/json;charset=UTF-8",
        Cookie: cookie
      }
    });
    if (!response.ok) {
      if (response.status === 401)
        CapacitorKV.remove(STORAGE.cookie);
      throw new Error(`Grade check failed with status ${response.status}`);
    }
    const current = createGradeSnapshot(await response.json());
    const previousValue = stored(STORAGE.snapshot);
    if (previousValue) {
      const previous = JSON.parse(previousValue);
      const changes = diffGradeSnapshots(previous, current);
      const notifications = changes.map((change) => {
        const notification = formatGradeNotification(change);
        return {
          ...notification,
          autoCancel: true,
          id: nextNotificationId(),
          scheduleAt: new Date
        };
      });
      if (notifications.length) {
        CapacitorNotifications.schedule(notifications);
      }
    }
    CapacitorKV.set(STORAGE.snapshot, JSON.stringify(current));
    CapacitorKV.set(STORAGE.lastCheck, String(now.getTime()));
  };
  runner.addEventListener("gradeCheck", (resolve, reject) => {
    runGradeCheck().then(resolve).catch(reject);
  });
  runner.addEventListener("gradeSessionSync", (resolve, reject, details) => {
    try {
      const previousStudentId = stored(STORAGE.studentId);
      if (details.studentId && previousStudentId && previousStudentId !== String(details.studentId)) {
        CapacitorKV.remove(STORAGE.lastCheck);
        CapacitorKV.remove(STORAGE.snapshot);
      }
      if (details.baseUrl)
        CapacitorKV.set(STORAGE.baseUrl, details.baseUrl);
      if (details.cookie)
        CapacitorKV.set(STORAGE.cookie, details.cookie);
      if (details.studentId) {
        CapacitorKV.set(STORAGE.studentId, String(details.studentId));
      }
      if (details.settings) {
        CapacitorKV.set(STORAGE.settings, details.settings);
      }
      resolve();
    } catch (error) {
      reject(error);
    }
  });
  runner.addEventListener("gradeSettingsUpdate", (resolve, reject, details) => {
    try {
      if (details.settings) {
        CapacitorKV.set(STORAGE.settings, details.settings);
        const settings = JSON.parse(details.settings);
        if (!settings.enabled) {
          CapacitorKV.remove(STORAGE.lastCheck);
          CapacitorKV.remove(STORAGE.snapshot);
        }
      }
      resolve();
    } catch (error) {
      reject(error);
    }
  });
  runner.addEventListener("gradeSessionClear", (resolve, reject) => {
    try {
      for (const key of Object.values(STORAGE))
        CapacitorKV.remove(key);
      resolve();
    } catch (error) {
      reject(error);
    }
  });
})();
